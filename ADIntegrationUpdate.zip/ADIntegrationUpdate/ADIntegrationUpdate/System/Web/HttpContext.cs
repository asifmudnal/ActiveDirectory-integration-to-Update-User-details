﻿namespace System.Web
{
    internal class HttpContext
    {
    }
}