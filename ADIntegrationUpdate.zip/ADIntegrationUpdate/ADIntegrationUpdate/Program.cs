﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.DirectoryServices;
using System.Configuration;

namespace ADIntegrationUpdate
{
    class Program
    {
        static void Main(string[] args)
        {
           
            var UserDisplayName = "";
            using (DirectoryEntry de = new DirectoryEntry(ConfigurationManager.AppSettings["Path"].ToString()))
           // using (DirectoryEntry de = new DirectoryEntry("Add your LDAP Server Link"))
            using (DirectorySearcher searcher = new DirectorySearcher())
            {
                de.Username = ConfigurationManager.AppSettings["userName"].ToString();
                de.Password = ConfigurationManager.AppSettings["userPassword"].ToString();
                searcher.SearchRoot = de;
                searcher.Filter = "(&(objectClass=User)(objectCategory=Person)(sAMAccountName=Mukhthar))";
                searcher.SearchScope = System.DirectoryServices.SearchScope.Subtree;
                searcher.PropertiesToLoad.Add("displayName");
                searcher.Sort = new SortOption("displayName", SortDirection.Ascending);
                SearchResult results = searcher.FindOne();
                if (results != null)
                {
                    // create new object from search result  

                    DirectoryEntry entryToUpdate = results.GetDirectoryEntry();

                    // show existing title  

                    
                    UserDisplayName = entryToUpdate.Properties["displayName"][0].ToString();
                    Console.WriteLine("User Name   : " + UserDisplayName);
                }
                    
                }

            ADWork ADStuff = new ADWork();
            var titleStatus= ADStuff.SetAdInfo(UserDisplayName, ADWork.Property.title, "Team 12345", "Add username");
            var departmentStatus = ADStuff.SetAdInfo(UserDisplayName, ADWork.Property.department, "Application developemnt1 ", "Add username");
            Console.WriteLine("Status of tile update is:{0}",titleStatus);
            Console.WriteLine("Status of department update is:{0}", departmentStatus);
            var currentDate = DateTime.Now.ToString("ddMMyy");
            bool log = ExceptionLogging.WriteLog("Log-"+ currentDate + ".txt", "Status of tile update is:"+titleStatus + "/n Status of department update is:"+ departmentStatus);

            Console.ReadLine();
        }
            }



    }

