﻿using System;
using System.Collections;
using System.Text;
using System.IO;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices;
using System.Data;
using System.Configuration;

public class ADWork
{
    public string SetAdInfo(string objectFilter, Property objectName,string objectValue, string LdapDomain)
    {
        try
        {
            
            DirectoryEntry myLdapConnection = CreateDirectoryEntry();
            DirectorySearcher mySearcher = new DirectorySearcher(myLdapConnection);
            mySearcher.Filter = "(cn=" + objectFilter + ")";
            mySearcher.SearchScope = System.DirectoryServices.SearchScope.Subtree;
            mySearcher.PropertiesToLoad.Add("" + objectName + "");
            SearchResult result = mySearcher.FindOne();
            if (result != null)
            {
                DirectoryEntry entryToUpdate = result.GetDirectoryEntry();
                if (!(String.IsNullOrEmpty(objectValue)))
                {
                    if (result.Properties.Contains("" + objectName + ""))
                    {
                        entryToUpdate.Properties["" + objectName + ""].Value = objectValue;
                    }
                    else
                    {
                        entryToUpdate.Properties["" + objectName + ""].Add(objectValue);
                    }
                    entryToUpdate.CommitChanges();
                }

            }

            myLdapConnection.Close();
            myLdapConnection.Dispose();
            mySearcher.Dispose();
            return "success";

        }
        catch
        {
            if ((String.IsNullOrEmpty(objectValue)))
                Console.WriteLine("Error");
            return "Invalid Employee ID";


        }

    }
    static DirectoryEntry CreateDirectoryEntry()
    {
        // create and return new LDAP connection with desired settings  

        DirectoryEntry ldapConnection = new DirectoryEntry("192.168.1.24", ConfigurationManager.AppSettings["userName"].ToString(), ConfigurationManager.AppSettings["userPassword"].ToString());
        ldapConnection.Path = ConfigurationManager.AppSettings["Path"].ToString();
        ldapConnection.AuthenticationType = AuthenticationTypes.Secure;
        return ldapConnection;
    }

    public enum Property
    {
        title, displayName, sn, l, postalCode, physicalDeliveryOfficeName, telephoneNumber,
        mail, givenName, initials, co, department, company,
        streetAddress, employeeID, mobile, userPrincipalName
    }
}