﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using context = System.Web.HttpContext;
using System.DirectoryServices;


namespace ADIntegrationUpdate
{
    public static class ExceptionLogging
    {
        
        public static bool WriteLog(string strFileName, string strMessage)
        {
            try
            {
                string filepath = @"C:\TawnADIntegrationWebService\LogMessage\";  //Text File Path
                if (!Directory.Exists(filepath))
                {
                    Directory.CreateDirectory(filepath);

                }
                filepath = filepath + DateTime.Today.ToString("dd-MM-yy") + ".txt";   //Text File Name
                if (!File.Exists(filepath))
                {

                    
                    File.Create(filepath).Dispose();

                }
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    string fileName = @"C:\TawnADIntegrationWebService\LogMessage\";
                    FileStream objFilestream = new FileStream(string.Format("{0}\\{1}", fileName, strFileName), FileMode.Append, FileAccess.Write);
                    StreamWriter objStreamWriter = new StreamWriter((Stream)objFilestream);
                    objStreamWriter.WriteLine(strMessage);
                    objStreamWriter.Close();
                    objFilestream.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        } 
    }
}

  
      
  



